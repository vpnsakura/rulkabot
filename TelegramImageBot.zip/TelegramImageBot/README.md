mkdir -p /opt/rule34bot
cd /opt/rule34bot
```

2. Скопируйте файлы в директорию:
   - bot.py
   - config.py
   - install.sh
   - README.md


3. Запустите установку:
```bash
chmod +x install.sh
./install.sh
```

4. Следуйте инструкциям установщика

## Ручная установка (Альтернативный метод)

1. Установите зависимости:
```bash
apt update
apt install -y python3 python3-pip
pip3 install aiogram aiohttp
```

2. Создайте файл с переменными окружения:
```bash
echo "BOT_TOKEN=ваш_токен_бота" > .env
```

3. Создайте systemd сервис:
```bash
cat > /etc/systemd/system/rule34bot.service << 'EOF'
[Unit]
Description=Rule34 Telegram Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/rule34bot
ExecStart=/usr/bin/python3 bot.py
Restart=always

[Install]
WantedBy=multi-user.target
EOF
```

4. Активируйте и запустите сервис:
```bash
systemctl daemon-reload
systemctl enable rule34bot
systemctl start rule34bot
```


## Управление ботом

### Проверка статуса
```bash
systemctl status rule34bot
```

### Просмотр логов
```bash
journalctl -u rule34bot -f
```

### Управление сервисом
```bash
# Перезапуск бота
systemctl restart rule34bot

# Остановка бота
systemctl stop rule34bot

# Запуск бота
systemctl start rule34bot
```

## Использование

### Inline режим
В любом чате введите @имя_вашего_бота и поисковый запрос
Пример: `@your_bot_name cat`

### Команды
- `/start` - Начало работы с ботом
- `/r34 запрос` - Поиск по запросу

## Возможности
- Inline-режим с пагинацией
- Кэширование результатов
- Просмотр тегов
- Скачивание изображений
- Фильтрация контента

## Устранение проблем

### Бот не запускается
1. Проверьте статус сервиса:
```bash
systemctl status rule34bot
```

2. Проверьте логи:
```bash
journalctl -u rule34bot -n 100
```

3. Проверьте файл .env:
```bash
cat /opt/rule34bot/.env