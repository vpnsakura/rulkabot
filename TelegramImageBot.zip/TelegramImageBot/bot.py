import os
import logging
import asyncio
from typing import Optional, Dict, List
import aiohttp
from aiogram import Bot, Dispatcher, Router, types
from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQuery,
    InlineQueryResultPhoto,
    BufferedInputFile
)
from aiogram.filters import Command
import time
from config import (
    BOT_TOKEN,
    API_BASE_URL,
    API_TIMEOUT,
    RESULTS_PER_PAGE,
    INLINE_RESULTS_LIMIT,
    MAX_CACHE_ITEMS,
    CACHE_TIMEOUT,
    LOG_FORMAT,
    LOG_LEVEL
)
from api_client import APIClient

# Настройка логирования
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format=LOG_FORMAT
)
logger = logging.getLogger(__name__)

# Инициализация API клиента
api_client = APIClient()

# Кэш для хранения результатов поиска
search_cache = {}

def clean_old_cache():
    """Очистка старого кэша"""
    current_time = time.time()
    expired_keys = [
        k for k, v in search_cache.items()
        if current_time - v['timestamp'] > CACHE_TIMEOUT
    ]
    for k in expired_keys:
        del search_cache[k]

    # Если кэш всё ещё слишком большой, удаляем самые старые записи
    if len(search_cache) > MAX_CACHE_ITEMS:
        sorted_items = sorted(
            search_cache.items(),
            key=lambda x: x[1]['timestamp']
        )
        for k, _ in sorted_items[:len(search_cache) - MAX_CACHE_ITEMS]:
            del search_cache[k]

def get_result_keyboard(page: int, has_next: bool) -> InlineKeyboardMarkup:
    """Создает клавиатуру с кнопками навигации и действий"""
    buttons = []
    row = []

    if page > 1:
        row.append(InlineKeyboardButton(text="⬅️ Назад", callback_data=f"page_{page-1}"))
    if has_next:
        row.append(InlineKeyboardButton(text="➡️ Дальше", callback_data=f"page_{page+1}"))

    buttons.append(row)
    row = []
    row.append(InlineKeyboardButton(text="💾 Скачать", callback_data=f"download_{page}"))
    row.append(InlineKeyboardButton(text="🏷 Теги", callback_data=f"tags_{page}"))
    buttons.append(row)

    return InlineKeyboardMarkup(inline_keyboard=buttons)

async def download_and_send_image(bot: Bot, chat_id: int, file_url: str):
    """Скачивает и отправляет изображение пользователю"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(file_url) as response:
                if response.status == 200:
                    content = await response.read()
                    file = BufferedInputFile(
                        content,
                        filename=f"image_{hash(file_url)}.jpg"
                    )
                    await bot.send_document(chat_id, document=file)
                else:
                    raise Exception(f"Failed to download image: {response.status}")
    except Exception as e:
        logger.error(f"Error downloading image: {str(e)}")
        await bot.send_message(chat_id, "❌ Ошибка при скачивании изображения")

async def main():
    # Инициализация бота и диспетчера
    bot = Bot(token=BOT_TOKEN)
    dp = Dispatcher()
    router = Router()

    @router.inline_query()
    async def inline_search(query: InlineQuery):
        """Обработчик инлайн-запросов с поддержкой пагинации"""
        search_text = query.query.strip()
        offset = int(query.offset) if query.offset else 0
        logger.info(f"Received inline query: {search_text}, offset: {offset}")

        if not search_text:
            return await query.answer(
                results=[],
                switch_pm_text="🔍 Введите тег для поиска",
                switch_pm_parameter="start",
                cache_time=1
            )

        try:
            # Запрашиваем результаты через API клиент
            results = await api_client.search_items(search_text, offset // RESULTS_PER_PAGE)

            if not results:
                return await query.answer(
                    results=[],
                    switch_pm_text="😕 Ничего не найдено",
                    switch_pm_parameter="start",
                    cache_time=1
                )

            # Подготавливаем inline результаты
            inline_results = []
            start_idx = offset % RESULTS_PER_PAGE
            end_idx = min(start_idx + INLINE_RESULTS_LIMIT, len(results))

            for idx, item in enumerate(results[start_idx:end_idx], start=offset):
                try:
                    result = InlineQueryResultPhoto(
                        id=str(idx),
                        photo_url=item['file_url'],
                        thumbnail_url=item['preview_url'],
                        photo_width=item['width'] or 100,
                        photo_height=item['height'] or 100,
                        caption=f"🏷 Теги: {item['tags'][:200]}..."
                    )
                    inline_results.append(result)
                except Exception as e:
                    logger.error(f"Error creating inline result {idx}: {str(e)}")
                    continue

            has_more = len(results) > end_idx
            next_offset = str(offset + INLINE_RESULTS_LIMIT) if has_more else ""

            await query.answer(
                results=inline_results,
                next_offset=next_offset,
                cache_time=30,
                is_personal=True
            )

        except Exception as e:
            logger.error(f"Inline search error: {str(e)}")
            await query.answer(
                results=[],
                switch_pm_text="😢 Произошла ошибка",
                switch_pm_parameter="error",
                cache_time=1
            )

    @router.message(Command("start"))
    async def cmd_start(message: Message):
        """Обработчик команды /start"""
        await message.answer(
            "👋 Привет! Я бот для поиска изображений.\n"
            "✨ Используйте команду /r34 <запрос> для поиска\n"
            "🔍 Или введите @имя_бота и запрос в любом чате"
        )

    @router.message(Command("r34"))
    async def cmd_search(message: Message):
        """Обработчик команды /r34"""
        query = message.text.replace('/r34', '').strip()

        if not query:
            await message.answer(
                "❌ Пожалуйста, укажите поисковый запрос!\n"
                "Пример: /r34 nature"
            )
            return

        try:
            processing_msg = await message.answer("🔍 Ищу...")

            results = await api_client.search_items(query)

            if not results:
                await processing_msg.edit_text("😕 По вашему запросу ничего не найдено.")
                return

            # Сохраняем результаты в кэш
            search_cache[message.from_user.id] = {
                "query": query,
                "page": 1,
                "results": results,
                "timestamp": time.time()
            }

            result = results[0]
            file_url = result.get('file_url', '')
            has_next = len(results) > 1

            await message.answer_photo(
                file_url,
                reply_markup=get_result_keyboard(1, has_next)
            )
            await processing_msg.delete()

        except Exception as e:
            logger.error(f"Search error: {str(e)}")
            await message.answer("😢 Произошла ошибка при поиске. Попробуйте позже.")

    @router.callback_query(lambda c: c.data and c.data.startswith(('page_', 'download_', 'tags_')))
    async def process_callback(callback: CallbackQuery):
        """Обработчик нажатий на инлайн-кнопки"""
        user_id = callback.from_user.id

        try:
            if user_id not in search_cache:
                await callback.answer("❌ Поиск устарел. Сделайте новый запрос.")
                return

            action, value = callback.data.split('_')
            page = int(value)
            cache = search_cache[user_id]

            if action == 'page':
                if page <= len(cache["results"]) and page > 0:
                    result = cache["results"][page - 1]
                    file_url = result.get('file_url', '')
                    has_next = page < len(cache["results"])

                    try:
                        await callback.message.edit_media(
                            types.InputMediaPhoto(media=file_url),
                            reply_markup=get_result_keyboard(page, has_next)
                        )
                    except Exception as e:
                        logger.error(f"Error updating media: {str(e)}")
                        await callback.message.answer_photo(
                            file_url,
                            reply_markup=get_result_keyboard(page, has_next)
                        )
                        await callback.message.delete()
                else:
                    await callback.answer("❌ Страница не найдена")

            elif action == 'download':
                result = cache["results"][page - 1]
                file_url = result.get('file_url', '')
                await download_and_send_image(callback.bot, user_id, file_url)
                await callback.answer("✅ Отправляю изображение")

            elif action == 'tags':
                result = cache["results"][page - 1]
                tags = result.get('tags', 'Нет тегов')
                await callback.message.reply(f"🏷 Теги:\n{tags}")
                await callback.answer()

        except Exception as e:
            logger.error(f"Callback error: {str(e)}")
            await callback.answer("❌ Произошла ошибка при обработке запроса")

    dp.include_router(router)

    try:
        logger.info("Starting bot...")
        await dp.start_polling(bot)
    finally:
        if api_client:
            await api_client.close()
        await bot.session.close()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot stopped")
    except Exception as e:
        logger.error(f"Critical error: {e}")